<?php
/*
Plugin Name: Hello Footer
Description: A simple plugin that adds the text "Hello" to the footer of the website.
Version: 1.0
Author: Your Name
*/

function hello_footer_add_text() {
  echo 'Hello';
}
add_action('wp_footer', 'hello_footer_add_text');
?>
